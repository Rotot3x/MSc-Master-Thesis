# MSO MDOC Credential Format Plugin

## Description

This plugin provides `mso_mdoc` credential support for the OID4VCI plugin. It acts as a module, dynamically loaded by the OID4VCI plugin, takes input parameters, and constructs and signs `mso_mdoc` credentials.

## Configuration

No configuration is required for this plugin.
