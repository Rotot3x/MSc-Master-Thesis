"""MDOC test cases."""
