"""MSO test cases."""
