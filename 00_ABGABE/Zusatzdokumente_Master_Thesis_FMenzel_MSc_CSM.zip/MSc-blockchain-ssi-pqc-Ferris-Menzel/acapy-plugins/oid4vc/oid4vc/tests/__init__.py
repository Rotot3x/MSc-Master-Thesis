"""OpenID4VCI tests."""
