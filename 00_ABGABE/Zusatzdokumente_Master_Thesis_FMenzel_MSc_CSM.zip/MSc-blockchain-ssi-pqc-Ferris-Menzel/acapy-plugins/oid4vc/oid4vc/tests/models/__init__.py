"""Tests for OpenID4VCI Models."""
