"""CredentialProcessor test."""
