# JWT_VC_JSON Credential Format

## Description

This plugin provides `jwt_vc_json` credential support for the OID4VCI plugin. It acts as a module, dynamically loaded by the OID4VCI plugin, takes input parameters, and constructs and signs `jwt_vc_json` credentials.

## Configuration

No configuration is required for this plugin.
