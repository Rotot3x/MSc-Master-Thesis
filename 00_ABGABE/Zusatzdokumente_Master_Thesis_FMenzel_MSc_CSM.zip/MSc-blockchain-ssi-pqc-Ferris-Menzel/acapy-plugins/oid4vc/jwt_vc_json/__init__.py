"""jwt_vc_json credential handler plugin."""

from .cred_processor import JwtVcJsonCredProcessor

__all__ = ["JwtVcJsonCredProcessor"]
