"""Error messages for did cheqd."""

DID_CHEQD_REQUIRED_MSG = "AnonCreds interface requires AskarAnonCreds profile"
