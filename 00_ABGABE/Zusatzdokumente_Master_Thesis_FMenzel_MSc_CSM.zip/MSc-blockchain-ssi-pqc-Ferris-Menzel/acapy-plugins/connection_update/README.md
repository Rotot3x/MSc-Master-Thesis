# Connection Update

## Description

- v1_0
    - Creates a new endpoint PUT /connections/{conn_id} that allows a controller to update the connection alias label.

## Configuration

- No additional configuration required.
