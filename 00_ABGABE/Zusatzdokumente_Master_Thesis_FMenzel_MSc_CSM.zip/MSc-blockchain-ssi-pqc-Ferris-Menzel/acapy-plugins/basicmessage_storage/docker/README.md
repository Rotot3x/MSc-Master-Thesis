This image is not intended for production as it copies the plugin source and loads its dependencies (including ACA-Py) along with simplistic ACA-Py configuration files.

- [default.yml](default.yml) is a multitenant ACA-Py instance.
- [integration.yml](integration.yml) is a single tenant configuration intended for running the [integration tests](../integration/README.md). There is no security on these agents.